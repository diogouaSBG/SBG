// ─────────────────────────────────────────────────────────────────────────────
// authConfig.js
//
// INSTRUÇÕES DE CONFIGURAÇÃO:
//
// 1. Vai a https://portal.azure.com
// 2. Pesquisa "App registrations" > "New registration"
// 3. Nome: "INETUM Viagens"
//    Tipo de conta: "Accounts in this organizational directory only"
//    Redirect URI: Single-page application (SPA) → https://SEU_URL
// 4. Depois de criar, copia o "Application (client) ID" → CLIENT_ID abaixo
// 5. Copia o "Directory (tenant) ID"                   → TENANT_ID abaixo
// 6. Em "API permissions" adiciona:
//    - Microsoft Graph → Delegated → Sites.ReadWrite.All
//    - Microsoft Graph → Delegated → User.Read
//    Clica em "Grant admin consent"
// 7. Em "Authentication" confirma que o Redirect URI está correto
//
// ─────────────────────────────────────────────────────────────────────────────

export const CLIENT_ID  = "COLOCA_AQUI_O_CLIENT_ID";   // App registration → Application ID
export const TENANT_ID  = "COLOCA_AQUI_O_TENANT_ID";   // App registration → Directory ID

// URL do teu site SharePoint (ex: https://inetum.sharepoint.com/sites/Projeto)
export const SHAREPOINT_SITE_URL = "https://INETUM.sharepoint.com/sites/NOME_DO_SITE";

// Nome da lista SharePoint (cria com este nome exato)
export const LIST_NAME = "Viagens";

// ─── MSAL config (não alterar) ───────────────────────────────────────────────
export const msalConfig = {
  auth: {
    clientId: CLIENT_ID,
    authority: `https://login.microsoftonline.com/${TENANT_ID}`,
    redirectUri: window.location.origin,
  },
  cache: {
    cacheLocation: "sessionStorage",
    storeAuthStateInCookie: false,
  },
};

export const loginRequest = {
  scopes: ["User.Read", "Sites.ReadWrite.All"],
};
