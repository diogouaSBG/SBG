// ─────────────────────────────────────────────────────────────────────────────
// sharepoint.js  —  CRUD na lista SharePoint via Microsoft Graph API
// ─────────────────────────────────────────────────────────────────────────────
import { loginRequest, SHAREPOINT_SITE_URL, LIST_NAME } from "./authConfig";

// Obtém token de acesso via MSAL
const getToken = async (msalInstance) => {
  const accounts = msalInstance.getAllAccounts();
  if (accounts.length === 0) throw new Error("Não autenticado");
  const response = await msalInstance.acquireTokenSilent({ ...loginRequest, account: accounts[0] });
  return response.accessToken;
};

// Resolve o ID interno do site SharePoint
const getSiteId = async (token) => {
  const hostname = new URL(SHAREPOINT_SITE_URL).hostname;
  const sitePath = new URL(SHAREPOINT_SITE_URL).pathname;
  const res = await fetch(
    `https://graph.microsoft.com/v1.0/sites/${hostname}:${sitePath}`,
    { headers: { Authorization: `Bearer ${token}` } }
  );
  const data = await res.json();
  return data.id;
};

// Resolve o ID da lista pelo nome
const getListId = async (token, siteId) => {
  const res = await fetch(
    `https://graph.microsoft.com/v1.0/sites/${siteId}/lists?$filter=displayName eq '${LIST_NAME}'`,
    { headers: { Authorization: `Bearer ${token}` } }
  );
  const data = await res.json();
  if (!data.value || data.value.length === 0) throw new Error(`Lista "${LIST_NAME}" não encontrada no SharePoint`);
  return data.value[0].id;
};

// Converte item SharePoint → objeto da app
const mapItem = (item) => ({
  id: item.id,
  name:        item.fields.Consultor    || "",
  zone:        item.fields.Zona         || "",
  departDay:   item.fields.DiaPartida   || "",
  departTime:  item.fields.HoraPartida  || "",
  returnDay:   item.fields.DiaRegresso  || "",
  returnTime:  item.fields.HoraRegresso || "",
  nights:      item.fields.Noites       || 0,
  portoLocation: item.fields.Hotel      || "",
  semana:      item.fields.Semana       || "",
});

// ── Buscar viagens de uma semana ──────────────────────────────────────────────
export const fetchTrips = async (msalInstance, semana) => {
  try {
    const token  = await getToken(msalInstance);
    const siteId = await getSiteId(token);
    const listId = await getListId(token, siteId);

    const res = await fetch(
      `https://graph.microsoft.com/v1.0/sites/${siteId}/lists/${listId}/items?$expand=fields&$filter=fields/Semana eq '${semana}'`,
      { headers: { Authorization: `Bearer ${token}` } }
    );
    const data = await res.json();
    return (data.value || []).map(mapItem);
  } catch (err) {
    console.error("fetchTrips error:", err);
    return [];
  }
};

// ── Criar viagem ──────────────────────────────────────────────────────────────
export const createTrip = async (msalInstance, trip, semana) => {
  const token  = await getToken(msalInstance);
  const siteId = await getSiteId(token);
  const listId = await getListId(token, siteId);

  const res = await fetch(
    `https://graph.microsoft.com/v1.0/sites/${siteId}/lists/${listId}/items`,
    {
      method: "POST",
      headers: { Authorization: `Bearer ${token}`, "Content-Type": "application/json" },
      body: JSON.stringify({
        fields: {
          Consultor:    trip.name,
          Zona:         trip.zone,
          DiaPartida:   trip.departDay,
          HoraPartida:  trip.departTime,
          DiaRegresso:  trip.returnDay,
          HoraRegresso: trip.returnTime,
          Noites:       trip.nights,
          Hotel:        trip.portoLocation,
          Semana:       semana,
        },
      }),
    }
  );
  const data = await res.json();
  return mapItem(data);
};

// ── Apagar viagem ─────────────────────────────────────────────────────────────
export const deleteTrip = async (msalInstance, itemId) => {
  const token  = await getToken(msalInstance);
  const siteId = await getSiteId(token);
  const listId = await getListId(token, siteId);

  await fetch(
    `https://graph.microsoft.com/v1.0/sites/${siteId}/lists/${listId}/items/${itemId}`,
    { method: "DELETE", headers: { Authorization: `Bearer ${token}` } }
  );
};
