# 🚄 INETUM Viagens — Teams Tab App + SharePoint

Coordenação de viagens semanais Lisboa ↔ Porto com dados partilhados via SharePoint.

---

## 📋 PRÉ-REQUISITOS

- Office 365 empresarial (já tens ✓)
- Node.js instalado (https://nodejs.org)
- Acesso ao portal Azure (portal.azure.com) com conta da empresa

---

## PASSO 1 — Criar a Lista no SharePoint

1. Vai ao teu site SharePoint da empresa
2. Clica em **+ Novo** > **Lista**
3. Nome da lista: **Viagens** (exatamente assim)
4. Adiciona estas colunas (Definições > Adicionar coluna):

| Nome da coluna | Tipo         |
|----------------|--------------|
| Consultor      | Linha de texto |
| Zona           | Linha de texto |
| DiaPartida     | Linha de texto |
| HoraPartida    | Linha de texto |
| DiaRegresso    | Linha de texto |
| HoraRegresso   | Linha de texto |
| Noites         | Número        |
| Hotel          | Linha de texto |
| Semana         | Linha de texto |

---

## PASSO 2 — Registar App no Azure

1. Vai a https://portal.azure.com
2. Pesquisa **"App registrations"** > **"New registration"**
3. Preenche:
   - Nome: `INETUM Viagens`
   - Tipo de conta: **Accounts in this organizational directory only**
   - Redirect URI: **Single-page application (SPA)** → `https://SEU_URL` (podes colocar `http://localhost:3000` para testes)
4. Clica **Register**
5. Copia o **Application (client) ID** e o **Directory (tenant) ID**

6. Em **API permissions** > **Add a permission** > **Microsoft Graph** > **Delegated**:
   - `User.Read`
   - `Sites.ReadWrite.All`
   - Clica em **Grant admin consent**

---

## PASSO 3 — Configurar a App

Edita o ficheiro `src/authConfig.js` e preenche:

```js
export const CLIENT_ID  = "COLA_AQUI_O_CLIENT_ID";
export const TENANT_ID  = "COLA_AQUI_O_TENANT_ID";
export const SHAREPOINT_SITE_URL = "https://INETUM.sharepoint.com/sites/NOME_DO_SITE";
```

---

## PASSO 4 — Instalar e Build

```bash
npm install
npm run build
```

---

## PASSO 5 — Deploy

### Opção A — Netlify (mais rápido, sem linha de comandos)
1. Vai a https://app.netlify.com/drop
2. Arrasta a pasta `build/` para o browser
3. Copia o URL gerado (ex: `https://random-name.netlify.app`)
4. Volta ao Azure App Registration e adiciona esse URL como Redirect URI

### Opção B — Azure Static Web Apps
```bash
npm install -g @azure/static-web-apps-cli
swa deploy ./build --app-name inetum-viagens
```

---

## PASSO 6 — Adicionar ao Teams

1. Abre o canal do projeto no Teams
2. Clica em **+** > **Website**
3. Cola o URL do deploy
4. Nome: **Viagens** → Guardar

---

## 🗂 Estrutura do Projeto

```
inetum-viagens/
├── src/
│   ├── index.js        # Entry point com MSAL Provider
│   ├── App.js          # App principal
│   ├── authConfig.js   # ⚙️ CONFIGURAR AQUI: Client ID, Tenant ID, SharePoint URL
│   └── sharepoint.js   # Integração Microsoft Graph API
├── public/
│   └── index.html
├── teams-manifest/
│   └── manifest.json
└── package.json
```
